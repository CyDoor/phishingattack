<?php
mysql_select_db('db',mysql_connect('localhost','root',''))or die(mysql_error());   

$insert="LOAD DATA INFILE 'C:/xampp/htdocs/phish/File.csv' INTO TABLE phish2 FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' SET id=null";
	$rs=mysql_query($insert) or die(mysql_error());

//LOAD DATA INFILE 'path/to/file.csv' INTO TABLE your_table FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' SET id=null;

?>