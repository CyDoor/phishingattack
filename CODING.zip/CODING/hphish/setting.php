<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">

<title>Phish Detection</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<style>
.button {
  display: block;
  width: 115px;
  height: 25px;
  background: #4E9CAF;
  padding: 10px;
  text-align: center;
  border-radius: 5px;
  color: white;
  font-weight: bold;
}
</style>
</head>
<body id="top">
<?php
session_start();
?>
<div class="wrapper col1">
  <div id="header">
<center>

<h1>    <font size="10"> <a href="#">Detection of Phishing Web Pages</a></h1></font>
      <p><strong>Enjoy the Unintrupted Life</strong></p>

</center>

    <br class="clear" />
  </div>
</div>
<div class="wrapper col2">
  <div id="topbar">
    <div id="topnav">
      <ul>
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="login.php#toregister">Register</a></li>
        <li><a href="Search1.php">Search Phish</a></li>
        <li><a href="setting.php">Our Settings</a>

        </li>

      </ul>
    </div>
    <div id="search">
<?php
if(isset($_SESSION['log']))
 echo "<a href=logout.php>
  <input type=submit name=go id=go value=Logout>
</a> ";
else
echo "<a href=login.php#tologin>
  <input type=submit name=go id=go value=SignIn>
</a> ";
?> 
    </div>
    <br class="clear" />
  </div>
</div>
<div class="wrapper col5">
  <div id="container">
    <div id="content">
      <h2>Configuration setting</h2>
<p> Steps </p>
<p> 1.  Create Database with name db</p>
<p>2. Import the sql file into the database</p>
<p> 3. Run auto config.php</p>
<p> 4. Delete the Configuration file</p>
<p> 5.Check the DB</p>
<p>6. Register the User</p>
<p> 7. Sign in the user</p>
<p>8. Hunt your Phishing Pages</p>
<p>9. Logout after completing your Hunt</p>
    </div>
       </div>
    <br class="clear" />
  </div>
</div>
<div class="wrapper col6">
  <div id="footer">
    <div id="login">
      <h2>Client Login !</h2>
      <p>Registration </p>
      <form action="#" method="post">
        <fieldset>
          <legend>Client Login</legend>
          <div class="fl_left">
            <input type="text" value="Enter email address&hellip;"  onfocus="this.value=(this.value=='Enter email address&hellip;')? '' : this.value ;" />
            <input type="password" value="Enter password&hellip;"  onfocus="this.value=(this.value=='Enter password&hellip;')? '' : this.value ;" />
          </div>
          <div class="fl_right">
            <input type="submit" name="login_go" id="login_go" value="&raquo;" />
          </div>
        </fieldset>
      </form>
      <p><a href="#">&raquo; Lost Your Password</a> | <a href="#">Create An Account &raquo;</a></p>
    </div>
    <div class="footbox">
      <h2>Lacus interdum</h2>
      <ul>
        <li><a href="#">Praesent et eros</a></li>
        <li><a href="#">Praesent et eros</a></li>
        <li><a href="#">Lorem ipsum dolor</a></li>
        <li><a href="#">Suspendisse in neque</a></li>
        <li class="last"><a href="#">Praesent et eros</a></li>
      </ul>
    </div>
    <div class="footbox">
      <h2>Steps</h2>
      <ul>
        <li><a href="login.php#toregister">Register</a></li>
        <li><a href="login.php">Login</a></li>
        <li><a href="search1.php">Search Stack</a></li>
        <li><a href="index.php">Suspendisse in neque</a></li>
        <li class="last"><a href="index.php">Praesent et eros</a></li>
      </ul>
    </div>
   
    <br class="clear" />
  </div>
</div>
<div class="wrapper col7">
  <div id="copyright">
    <p class="fl_left">Copyright &copy; 2016 - All Rights Reserved - <a href="#">Phish Domain</a></p>
    <p class="fl_right">Nature <a href="#" title="Phish Web Page Detection">Phish</a></p>
    <br class="clear" />
  </div>
</div>
</body>
</html>
