<?php
session_start();
if(isset($_SESSION['log']))
  unset($_SESSION['log']);
echo " <script>alert('Successfully Logged out....');</script><script>window.location='index.php';</script>";
?>