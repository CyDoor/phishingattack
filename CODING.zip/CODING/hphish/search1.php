<?php
session_start();
if(!isset($_SESSION['log']))
echo " <script>alert('Please Register your Information ');</script><script>window.location='index.php';</script>";
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Phishing Webpage Detection</title>

<link rel="stylesheet" type="text/css" href="styles.css" />

</head>

<body>

<div id="page">

    <h1>Phishing Webpage Detection</h1>

<form id="searchForm" action="search.php" method="GET">

    <input id="s" type="text" name="query" />
    <input id="submitButton"  type="submit" value="Search" />

   
   
            

                        
            <ul class="icons">
                <li class="web" title="Web Search" data-searchType="web">Web</li>
                <li class="images" title="Image Search" data-searchType="images">Images</li>
                <li class="news" title="News Search" data-searchType="news">News</li>
                <li class="videos" title="Video Search" data-searchType="video">Videos</li>
            </ul>
            
        </fieldset>
    </form>

    <div id="resultsDiv"></div>
    
</div>

</body>
</html>
