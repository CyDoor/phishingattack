
<html>
<body>
<?php
$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
//echo $url;

$url=filter_var($url,FILTER_SANITIZE_URL);

if(!filter_var($url,FILTER_VALIDATE_URL)===false)
{
	echo("$url is a valid url");
}
else
{
	echo ("$url is not a valid url");
}
?>
</body>
</html>