<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">

<title>Phish Detection</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<style>
.button {
  display: block;
  width: 115px;
  height: 25px;
  background: #4E9CAF;
  padding: 10px;
  text-align: center;
  border-radius: 5px;
  color: white;
  font-weight: bold;
}
</style>
</head>
<body id="top">
<?php
session_start();
?>
<div class="wrapper col1">
  <div id="header">
<center>

<h1>    <font size="10"> <a href="#">Detection of Phishing Web Pages</a></h1></font>
      <p><strong>Enjoy the Unintrupted Life</strong></p>

</center>

    <br class="clear" />
  </div>
</div>
<div class="wrapper col2">
  <div id="topbar">
    <div id="topnav">
      <ul>
        <li class="active"><a href="index.php">Home</a></li>
        
        <li><a href="Search1.php">Search Phish</a></li>
        <li><a href="setting.php">Our Settings</a>

        </li>

      </ul>
    </div>
    <div id="search">
<?php
if(isset($_SESSION['log']))
 echo "<a href=logout.php>
  <input type=submit name=go id=go value=Logout>
</a> ";
else
echo "<a href=login.php#tologin>
  <input type=submit name=go id=go value=LogIn>
</a> ";
?> 


    </div>
    <br class="clear" />
  </div>
</div>


<div class="wrapper col5">
  <div id="container">
    <div id="content">
      <h2>About Phish Detection</h2>
      <p>Online services have become important part of our lives as they allow anytime, anywhere access to information. Clearly, such services are not only useful for Internet users, but they have also become indispensable for financial organizations because they help reduce operational costs. For example, there are millions of users who use the Internet for performing online banking transactions. The web is convenient for users as they are not bound to the opening hours of banks and do not have to be physically present. Unfortunately, the usefulness of online services has been overshadowed by large-scale phishing attacks launched against Internet users.  <a href="#">OS Templates</a>.</p>
      <p>Phishing is a form of identity theft in which a combination of social engineering and web site spoofing techniques are used to trick a user into revealing confidential information with economic value. In a typical phishing attack, a large number of spoofed e-mails are sent to random users (i.e., analogous to spam e-mail). These e-mails are disguised such that an unsuspecting victim is easily convinced that the e-mail is coming from a legitimate organization such as a bank. Typically, these e-mails requests the victims to "update" their online banking information. </p>
      <p>However, because phishing has received significant press coverage and attention in the last couple of years, ironically, phishers are now often persuading victims to enter their online banking credentials as a precaution for the imminent phishing threat. In phishing e-mails, the request to update confidential information is often accompanied by a subtle threat in order to make the persuasion of the victim easier. For example, the phishers may convince victims that the failure to update their information will result in their banking account being suspended </p>

    </div>
   
    </div>
    <br class="clear" />
  </div>
</div>

</div>
</body>
</html>
