<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Phishing Webpage Detection</title>

<link rel="stylesheet" type="text/css" href="styles.css" />

</head>

<body>
<br><br><br><br><br><br><br><br><br><br>
<?php

mysql_connect("localhost", "root", "") or die("Error connecting to database: ".mysql_error());
    /*
        localhost - it's location of the mysql server, usually localhost
        root - your username
        third is your password
         
      
    */
     
    mysql_select_db("db") or die(mysql_error());

     
         

 $query = $_GET['query'];

     
    $min_length = 3;

     
    if(strlen($query) >= $min_length){ // if query length is more or equal minimum length then
         
        $query = htmlspecialchars($query);

         
        $query = mysql_real_escape_string($query);

         
        $raw_results = mysql_query("SELECT * FROM phish2
            WHERE (`url` LIKE '%".$query."%') OR (`urldetail` LIKE '%".$query."%')") or die(mysql_error());
             


         
        if(mysql_num_rows($raw_results) > 0){ // if one or more rows are returned do following
             
            while($results = mysql_fetch_array($raw_results)){

             echo "<center>";
             echo "<font size=10 color=red> This is Defected Phish Page</font> <br>";
             echo "<p><b>Verified:</b>".$results['verify']."</b></p>";
             
             echo "The URL Verified following Times";
              echo "<p><b>Url Description: </b>".$results['url']." <b> Verify By :</b> ".$results['urldetail']."</p>";


             echo "</center>";
break;
            }
             
        }
        else{ // if there is no matching rows do following
            echo "<center> The Url is Not Contain any worms </center>";
        }
         
    }
    else{ // if query length is less than minimum
        echo "Minimum length is ".$min_length;
    }
?>
</body>
</html>
