<?php
session_start();
if(isset($_SESSION['log']))
echo " <script>alert('Already logged in plz make logout to new user');</script><script>window.location='index.php';</script>";
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,700,300,600,800,400' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />


<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
    
        <meta charset="UTF-8" />
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Login and Registration Form </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="Login and Registration Form with HTML5 and CSS3" />
        <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
        <meta name="author" content="Codrops" />
        <link rel="shortcut icon" href="../favicon.ico"> 

<?php

mysql_select_db('db',mysql_connect('localhost','root',''))or die(mysql_error());   

if (isset($_POST['login'])){
			$username=$_POST['username'];
			$password=$_POST['password'];
 
 
			//'$query=mysql_query("select * from login where userid=' strtoupper(trim($username)) ' and PASSWORD= ' $password '") or die(mysql_error());
$query=mysql_query("select * from login where userid='".strtoupper(trim($username))."' and PASSWORD='".$password."'")or die(mysql_error());

			$count=mysql_num_rows($query);

			if ($count > 0){

$_SESSION['log']=$username;

 echo "<script>window.location='index.php';</script>";
			}
else
{echo "<script>alert('Incorrect Login.....');</script>";}
		}


if (isset($_POST['signup'])){ 

             			$depart=	"Null";
			$username=$_POST['emailsignup'];
			$password=$_POST['passwordsignup'];


		if(empty($depart) || empty($username)){
			echo "<label class='err'>All field is required</label>";

			echo " <script>alert('Empty Fields are not allowed');</script><script>window.location='login.php#toregister';</script>";
			}
	else
	{
//------------------------------
$rowSQL = mysql_query( "SELECT MAX( id ) AS max FROM `login`;" ) or die(mysql_error());
$row = mysql_fetch_array( $rowSQL );
$lrg = $row['max'];
//-----------------------------
	$insert="Insert into login(id,userid,password) values($lrg+1,'".strtoupper(trim($username))."','".trim($password)."')";
	$rs=mysql_query($insert) or die(mysql_error());
	echo "";
 ?>
 <script>alert('User Registered Successfully.....');</script>
<script>window.location='login.php';</script>
<?php }






 }


?>
<style>
span.tab{
    padding: 0 80px; /* Or desired space*/
}
.styled-select select {
   background: white;
   width: 400px;
   padding: 5px;
   font-size: 16px;
   line-height: 1;
   border: 0;
   border-radius: 0;
   height: 34px;
   -webkit-appearance: none;
   }
.styled-select {
   width: 400px;
   height: 34px;
   overflow: hidden;
   background: url(new_arrow.jpg) no-repeat right #ddd;
   border: 1px solid #ccc;
   }


</style>
    </head>
    <body>
        <div class="container">
          
            <header>
                <h1> <center>Login <span>And  Registration</center></span></h1>

            </header>
            <section>				
                <div id="container_demo" >

                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                            <form name="login" method="post" action="login.php"> 
                                <h1>Log in</h1> 
                                <p> 
                                    <label for="username" class="uname" data-icon="u" > Your email or username </label>
                                    <input id="username" name="username" required="required" type="text" placeholder="Email id"/>
                                </p>
                                <p> 
                                    <label for="password" class="youpasswd" data-icon="p"> Your password </label>
                                    <input id="password" name="password" required="required" type="password" placeholder="Password" /> 
                                </p>
                                <p class="keeplogin"> 
									<input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
									<label for="loginkeeping">Keep me logged in</label>
								</p>
                                <p class="login button"> 
                                    <input type="submit" name="login" value="Login" /> 
								</p>
                                <p class="change_link">
									
									<a href="#toregister" class="to_register">New Registration</a> Or <a href="index.php" class="to_register"> Home </a>
								</p>
                            </form>
                        </div>

                        <div id="register" class="animate form">
                            <form name="login1" method="post" action="login.php#toregister"> 
                                <h1> Sign up </h1> 


                                <p> 
                                    <label for="Useridsignup" class="Userid" > UserId Or Email</label>
                                    <input id="emailsignup" name="emailsignup" required="required"  placeholder="Username"/> 
                                </p>
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" >Your password </label>
                                    <input id="passwordsignup" name="passwordsignup" required="required" type="password" placeholder="Password"/>
                                </p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" data-icon="p">Please confirm your password </label>
                                    <input id="passwordsignup_confirm" name="passwordsignup_confirm" required="required" type="password" placeholder="Conform Password"/>
                                </p>
                                <p class="signin button"> 
	          <input type="submit" name="signup" value="Sign up"/> 
								</p>
                                <p class="change_link">  
									Already a member ?
									<a href="#tologin" class="to_register"> Go and log in </a>  Or 									<a href="index.php" class="to_register"> Home </a>
								</p>
                            </form>
                        </div>
						
                    </div>
                  
            </section>
        </div>
    </body>
</html>