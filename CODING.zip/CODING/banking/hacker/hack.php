<?php include '../core/connection.php'; ?>
<?php include '../core/function.php'; ?>
<?php
ob_start();
session_start();

if(!isset($_SESSION['hacker']))
{
	header('location: login.php');
}

if(isset($_GET['acc']))
{
	$acc = mysql_real_escape_string($_GET['acc']);
	$details = user_assets_account($acc);
}
else
{
	header('location: home.php');
}



?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<style type="text/css">
	html { 
		  background-color: blue;
		}
	</style>
</head>
<body>
<?php

# SEND FUND
if(isset($_POST['payee_name']) && isset($_POST['payee_account']) && isset($_POST['amount']))
{
	$error = Array();

	$payee_name = mysql_real_escape_string($_POST['payee_name']);
	$payee_account = mysql_real_escape_string($_POST['payee_account']);
	$amount = mysql_real_escape_string($_POST['amount']);

	if(customer_account_exists($payee_account) != 1)
	{
		$error[] = 'Account Number not exists!';
	}

	if($payee_name == '')
	{
		$error[] = 'Enter Payee Account Name';
	}

	if($payee_account == '')
	{
		$error[] = 'Enter Payee Account Number';
	}

	if($amount == '')
	{
		$error[] = 'Enter Amout to send funds!';
	}

	if($details['customer_deposit'] == 0)
	{
		$error[] = 'Insufficient Balance!';
	}

	if($details['customer_deposit'] <= $amount)
	{
		$error[] = 'Available Balance is Low!';
	}

	if(empty($error))
	{

		$debit = $details['customer_deposit'] - $amount;

		mysql_query("UPDATE customer SET customer_deposit = '$debit' WHERE customer_name = '$details[customer_name]'");

		$payee = user_assets_account($payee_account);

		$new_deposit = $payee['customer_deposit'] + $amount;

		mysql_query("UPDATE customer SET customer_deposit = '$new_deposit' WHERE customer_name = '$payee[customer_name]'");


		$date = date('d/M/Y');
		$statement = mysql_query("INSERT INTO statement (customer_account, payee_account, amount, dated) VALUES('$details[customer_account]', '$payee[customer_account]', '$amount', '$date')");

		if($statement)
		{
			echo '<script>alert("Fund Transfered Successfully!");</script>';
			//header('location: transfer.php');
		}


	}
	else
	{
		foreach ($error as $key => $value) {
			?>
				<script type="text/javascript">
				$(document).ready(function(){
					alert(<?php echo '"'.$value.'"'; ?>);
				});
				</script>
			<?php
		}
	}

}

?>




	
	<div class="page-full-width clearfix">

	<div class="navi clearfix">
	<div class='hack-logo'>HACKER TERMINAL</div>
	
	</div>
	<div class="naviga">
	
	</div>

	<div class="clearfix">
	<div class="hack-left">

		<form action="" method="post" class="hack">

			<fieldset>

				<p>
				<label>Target Account *</label>
				<input type="text" class="default-width-input round" name="customer_account" value="<?php echo $details['customer_account']; ?>" disabled />
				</p>

				<p>
				<label>Total Available Balance</label>
				<input type="text" class="default-width-input round" name="customer_deposit" value="<?php echo $details['customer_deposit']; ?>" disabled />
				</p>

				<p>
				<label>Payee Account Name *</label>
				<input type="text" class="default-width-input round" name="payee_name"/>
				</p>

				<p>
				<label>Payee Account Number *</label>
				<input type="text" class="default-width-input round" name="payee_account"/>
				</p>

				<p>
				<label>Amount (INR) *</label>
				<input type="text" class="default-width-input round" name="amount"/>
				</p>

				<input type="submit" value="SEND FUND" name="edit" class="button image-right text-upper round blue" id="add-category">

			</fieldset>

		</form>

	

	</div><!-- page-full-width -->



</body>
</html>