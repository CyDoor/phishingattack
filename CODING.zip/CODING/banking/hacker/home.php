<?php include '../core/connection.php'; ?>
<?php include '../core/function.php'; ?>
<?php
ob_start();
session_start();

if(!isset($_SESSION['hacker']))
{
	header('location: login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,700,300,600,800,400' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />
	<style type="text/css">
	html { 
		  background-color: blue;
		}
	</style>
</head>
<body>


<div class="page-full-width clearfix">

	<div class="navi clearfix">
	<div class='hack-logo'>HACKER TERMINAL</div>

	</div>

	<div class="naviga">
	
	</div>

	<div class="terminal-content clearfix">
	<table>
			<thead>
				<tr>
					<th>S.no</th>
					<th>Account No</th>
					<th>Name</th>
					<th>Password</th>
					<th>Amount (INR)</th>
					<th>Gain Access</th>
				</tr>
			</thead>
	
		<tbody>

		<?php

			$received = mysql_query("SELECT * FROM customer");
			while($rec = mysql_fetch_assoc($received))
			{
				$customer_id = $rec['customer_id'];
				$customer_account = $rec['customer_account'];
				$customer_name = $rec['customer_name'];
				$customer_password = $rec['customer_password'];
				$customer_deposit = $rec['customer_deposit'];
			?>

					<tr>
						<td>
							<?php echo $customer_id; ?>
						</td>
						<td>
							<?php echo $customer_account; ?>
						</td>
						<td><?php echo $customer_name; ?></td>
						<td><?php echo $customer_password; ?></td>
						<td><?php echo $customer_deposit; ?></td>
						<td><a href="hack.php?acc=<?php echo $customer_account; ?>">Hack</a></td>
					</tr>

			<?php

				
			}

		?>


		</tbody>
		</table>

	</div>

</div>

</body>
</html>