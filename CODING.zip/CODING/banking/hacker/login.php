<?php include '../core/connection.php'; ?>
<?php
ob_start();
session_start();

if(isset($_SESSION['hacker']))
{
	header('location: home.php');
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,700,300,600,800,400' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />
	<style type="text/css">
	html { 
		  background:blue; 
		  -webkit-background-size: cover;
		  -moz-background-size: cover;
		  -o-background-size: cover;
		  background-size: cover;
		}
	</style>
</head>
<body>

<div class="hacker-login">
<?php

if(isset($_POST['username']) && isset($_POST['password']))
{
	$username = mysql_real_escape_string($_POST['username']);
	$password = mysql_real_escape_string(md5($_POST['password']));

	$sql = mysql_query("SELECT * FROM hacker WHERE username = '$username' AND password = '$password' ");

	$row = mysql_num_rows($sql);

	if($row == 1)
	{
		$_SESSION['hacker'] = $username;
		header('location: home.php');
	}
	
}

?>	
<form action="" method="post">

<label>Root name</label>
<input type="text" name="username">

<label>Root password</label>
<input type="password" name="password">

<input type="submit" value="Root Access">

</form>
</div>
</body>
</html>