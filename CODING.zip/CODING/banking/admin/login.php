 <?php include '../core/connection.php'; ?>
<?php
ob_start();
session_start();

if(isset($_SESSION['bank']))
{
	header('location: home.php');
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,700,300,600,800,400' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />
</head>
<body>

<div id="top-bar">
	
	<div class="page-full-width">

	<h1 class="logo">ADMIN PANEL</h1>


	</div><!-- page-full-width -->

</div><!-- top-bar -->

<div id="header">

	<div class="page-full-width clearfix">
	
	<div id="login-intro" class="fl">

		<h1>Secure Login to Internet Banking</h1>
	

	</div><!-- login-intro -->

	<a href="#" class="fr"><!--<img src="img/company-logo.png" alt="Techforge" id="company-logo">--></a>


	</div><!-- page-full-width -->

</div><!-- header -->

<div id="content">
	<?php

if(isset($_POST['username']) && isset($_POST['password']))
{
	$username = mysql_real_escape_string($_POST['username']);
	$password = mysql_real_escape_string(md5($_POST['password']));

	$sql = mysql_query("SELECT * FROM bank WHERE username = '$username' AND password = '$password' ");

	$row = mysql_num_rows($sql);

	if($row == 1)
	{
		$_SESSION['bank'] = $username;
		header('location: home.php');
	}
	
}

?>	
	<form action="#" id="login-form" method="post">

	<fieldset>

		<p>
		<label>Username</label>
		<input type="text" id="login-username" class="round full-width" name="username" />
		</p>

		<p>
		<label>Password</label>
		<input type="password" id="login-password" class="round full-width" name="password" />
		</p>
		<input type="submit" value="Log in" class="button round image-right ic-right-arrow text-upper blue" />

	</fieldset>

	</form>

</div><!-- content -->
</body>
</html>