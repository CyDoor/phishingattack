<?php
session_start();
unset($_SESSION['bank']);
header('location: login.php');
?>