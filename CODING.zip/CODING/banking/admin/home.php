<?php include '../core/connection.php'; ?>
<?php include '../core/function.php'; ?>
<?php
ob_start();
session_start();

if(!isset($_SESSION['bank']))
{
	header('location: login.php');
}


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />
</head>
<body>

<div id="top-bar">
	
	<div class="page-full-width clearfix">

	<ul id="nav" class="fl">
		<li class="v-sep"><span class="logo">MY BANK.com</span></li>
		<li><a href="logout.php" class="button round dark image-left ic-menu-logout">Log out</a></li>
		
	</ul>

	<form action="#" id="search-form" class="fr">
		<fieldset>
			<input type="text" id="search-keyword" placeholder="Search..." class="button image-right ic-search round dark"  />
			<input type="hidden" value="submit" />
		</fieldset>
		</form>
	</div><!-- page-full-width -->

</div><!-- top-bar -->

<div id="header-with-tabs">

	<div class="page-full-width clearfix">
	
		<ul id="tabs">
			<li><a href="home.php" class="active-tab">VIEW CUSTOMER</a></li>
			<li><a href="addcustomer.php" >ADD CUSTOMERS</a></li>
		</ul>

	<a href="#" class="fr" id="company-logo-small"><!--<img src="img/company-logo.png" alt="Techforge" >--></a>


	</div><!-- page-full-width -->

</div><!-- header -->

<div id="content">
	
	<div class="page-full-width clearfix">

		<table>
			<thead>
				<tr>
					<th>S.no</th>
					<th>Account No</th>
					<th>Name</th>
					<th>Amount (INR)</th>
				</tr>
			</thead>
	
		<tbody>

		<?php

			$received = mysql_query("SELECT * FROM customer");
			while($rec = mysql_fetch_assoc($received))
			{
				$customer_id = $rec['customer_id'];
				$customer_account = $rec['customer_account'];
				$customer_name = $rec['customer_name'];
				$customer_deposit = $rec['customer_deposit'];
			?>

					<tr>
						<td>
							<?php echo $customer_id; ?>
						</td>
						<td>
							<?php echo $customer_account; ?>
						</td>
						<td><?php echo $customer_name; ?></td>
						<td><?php echo $customer_deposit; ?></td>
					</tr>

			<?php

				
			}

		?>


		

			
			
		</tbody>
		</table>

		

	</div><!-- page-full-width -->

</div><!-- content -->
</body>
</html>