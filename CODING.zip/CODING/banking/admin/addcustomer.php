<?php include '../core/connection.php'; ?>
<?php include '../core/function.php'; ?>
<?php
ob_start();
session_start();

if(!isset($_SESSION['bank']))
{
	header('location: login.php');
}


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />
	<script type="text/javascript" src="../js/jquery.js"></script>
</head>
<body>

<div id="top-bar">
	
	<div class="page-full-width clearfix">

	<ul id="nav" class="fl">
		<li class="v-sep"><span class="logo">MY BANK.com</span></li>
		<li><a href="logout.php" class="button round dark image-left ic-menu-logout">Log out</a></li>
		
	</ul>

	<form action="#" id="search-form" class="fr">
		<fieldset>
			<input type="text" id="search-keyword" placeholder="Search..." class="button image-right ic-search round dark"  />
			<input type="hidden" value="submit" />
		</fieldset>
		</form>
	</div><!-- page-full-width -->

</div><!-- top-bar -->

<div id="header-with-tabs">

	<div class="page-full-width clearfix">
	
		<ul id="tabs">
			<li><a href="home.php" >VIEW CUSTOMER</a></li>
			<li><a href="addcustomer.php" class="active-tab">ADD CUSTOMERS</a></li>
		</ul>

	<a href="#" class="fr" id="company-logo-small"><!--<img src="img/company-logo.png" alt="Techforge" >--></a>


	</div><!-- page-full-width -->

</div><!-- header -->

<div id="content">
	
	<div class="page-full-width clearfix">
<?php

# SEND FUND
if(isset($_POST['customer_account']) && isset($_POST['customer_name']) && isset($_POST['customer_password']) && isset($_POST['customer_deposit']))
{
	$error = Array();
	$customer_account = mysql_real_escape_string($_POST['customer_account']);
	$customer_name = mysql_real_escape_string($_POST['customer_name']);
	$customer_password = mysql_real_escape_string($_POST['customer_password']);
	$customer_deposit = mysql_real_escape_string($_POST['customer_deposit']);


	if(customer_account_exists($customer_account) == 1)
	{
		$error[] = 'Account Number already exists!';
	}

	if(customer_name_exists($customer_name) == 1)
	{
		$error[] = 'Account Name already exists!';
	}

	if($customer_account == '')
	{
		$error[] = 'Enter Account Number';
	}

	if($customer_name == '')
	{
		$error[] = 'Enter Customer Name';
	}

	if($_POST['customer_password'] == '')
	{
		$error[] = 'Enter Customer Password!';
	}

	if($customer_deposit == '')
	{
		$error[] = 'Enter Deposit Amount!';
	}


	if(empty($error))
	{

		

		$add = mysql_query("INSERT INTO customer (customer_account, customer_name, customer_password, customer_deposit) VALUES ('$customer_account', '$customer_name', '$customer_password', '$customer_deposit')");



		if($add)
		{
			echo '<script>alert("Customer Added Successfully!");</script>';
			//header('location: transfer.php');
		}


	}
	else
	{
		foreach ($error as $key => $value) {
			?>
				<script type="text/javascript">
				$(document).ready(function(){
					alert(<?php echo '"'.$value.'"'; ?>);
				});
				</script>
			<?php
		}
	}

}

?>
		<form action="" method="post">

			<fieldset>

				<p>
				<label>Account Number *</label>
				<input type="text" class="default-width-input round" name="customer_account"/>
				</p>

				<p>
				<label>Customer Name *</label>
				<input type="text" class="default-width-input round" name="customer_name"/>
				</p>

				<p>
				<label>Customer Password *</label>
				<input type="text" class="default-width-input round" name="customer_password"/>
				</p>

				
				<p>
				<label>Deposit Amount (INR) *</label>
				<input type="text" class="default-width-input round" name="customer_deposit"/>
				</p>

				<input type="submit" value="ADD CUSTOMER" name="edit" class="button image-right text-upper round blue ic-right-arrow" id="add-category">

			</fieldset>

		</form>
		

	</div><!-- page-full-width -->

</div><!-- content -->
</body>
</html>