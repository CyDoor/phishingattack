<div id="top-bar">
	
	<div class="page-full-width clearfix">

	<ul id="nav" class="fl">
		<li class="v-sep"><span class="logo">MY BANK.com</span></li>

		
		<li><a href="logout.php" class="button round dark image-left ic-menu-logout">Log out</a></li>
		
	</ul>

	<form action="#" id="search-form" class="fr">
		<fieldset>
			<input type="text" id="search-keyword" placeholder="Search..." class="button image-right ic-search round dark"  />
			<input type="hidden" value="submit" />
		</fieldset>
		</form>
	</div><!-- page-full-width -->

</div><!-- top-bar -->