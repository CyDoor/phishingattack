<?php
ob_start();

header('location: login.php');

?>