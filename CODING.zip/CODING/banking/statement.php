<?php include 'core/connection.php'; ?>
<?php include 'core/function.php';  ?>
<?php
ob_start();
session_start();

if(!isset($_SESSION['customer_name']))
{
	header('location: login.php');
}


$details = user_assets($_SESSION['customer_name']);

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />
</head>
<body>

<?php include 'temp/navigation.php'; ?>

<div id="header-with-tabs">

	<div class="page-full-width clearfix">
	
		<ul id="tabs">
			<li><a href="home.php" >ACCOUNT SUMMARY</a></li>
			<li><a href="transfer.php">TRANSFER FUNDS</a></li>
			<li><a href="statement.php" class="active-tab">STATEMENTS</a></li>
		</ul>

	<a href="#" class="fr" id="company-logo-small"><!--<img src="img/company-logo.png" alt="Techforge" >--></a>


	</div><!-- page-full-width -->

</div><!-- header -->

<div id="content">
	
	<div class="page-full-width clearfix">

		<table>
			<thead>
				<tr>
					<th>S.no</th>
					<th>Transcation</th>
					<th>Date</th>
					<th>Amount (INR)</th>
				</tr>
			</thead>
	
		<tbody>

		<?php

			$received = mysql_query("SELECT * FROM statement WHERE payee_account = '$details[customer_account]'");
			while($rec = mysql_fetch_assoc($received))
			{
				$statement_id = $rec['statement_id'];
				$sender_id = $rec['customer_account'];
				$sender = user_assets_account($sender_id);
				$amount = $rec['amount'];
				$dated = $rec['dated'];
			?>

					<tr>
						<td>
							1
						</td>
						<td>
							Received - Rs. <?php echo $amount; ?> (INR) - acc.no : <?php echo $sender_id; ?> - acc.name - <?php echo $sender['customer_name']; ?>
						</td>
						<td><?php echo $dated; ?></td>
						<td><?php echo $amount; ?></td>
					</tr>

			<?php

				
			}

		?>


		<?php

			$sender = mysql_query("SELECT * FROM statement WHERE customer_account = '$details[customer_account]'");
			while($rec = mysql_fetch_assoc($sender))
			{
				$statement_id = $rec['statement_id'];
				$receiver_id = $rec['payee_account'];
				$receiver = user_assets_account($receiver_id);
				$amount = $rec['amount'];
				$dated = $rec['dated'];
			?>

					<tr>
						<td>
							1
						</td>
						<td>
							Transfered - Rs. <?php echo $amount; ?> (INR) - acc.no : <?php echo $receiver['customer_account']; ?> - acc.name - <?php echo $receiver['customer_name']; ?>
						</td>
						<td><?php echo $dated; ?></td>
						<td><?php echo $amount; ?></td>
					</tr>

			<?php

				
			}

		?>

			
			
		</tbody>
		</table>

		<a href="home.php" class="sum-but clearfix">LINK TO SUMMARY</a>

	</div><!-- page-full-width -->

</div><!-- content -->

<div id="footer">
	
	<p>&copy; Copyright 2015. All rights reserved</p>

</div><!-- footer -->

</body>
</html>