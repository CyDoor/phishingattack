<?php include 'core/connection.php'; ?>
<?php include 'core/function.php'; ?>
<?php
ob_start();
session_start();

if(!isset($_SESSION['customer_name']))
{
	header('location: login.php');
}


$details = user_assets($_SESSION['customer_name']);

?>
<?php

if(isset($_POST['current_password']) && isset($_POST['new_password']))
{
	$current_password = mysql_real_escape_string($_POST['current_password']);
	$new_password = mysql_real_escape_string($_POST['new_password']);

	if($current_password == $details['customer_password'])
	{
		$sql = mysql_query("UPDATE customer SET customer_password = '$new_password' WHERE customer_id = '$details[customer_id]'");
		if($sql)
		{
			echo '<script>alert("Password Changed Successfully!");</script>';
		}
	}
	else
	{
		echo '<script>alert("Current Username Not Match");</script>';
	}

}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />
	<script type="text/javascript" src="js/jquery.js"></script>
</head>
<body>
<?php

# SEND FUND
if(isset($_POST['payee_name']) && isset($_POST['payee_account']) && isset($_POST['amount']))
{
	$error = Array();

	$payee_name = mysql_real_escape_string($_POST['payee_name']);
	$payee_account = mysql_real_escape_string($_POST['payee_account']);
	$amount = mysql_real_escape_string($_POST['amount']);

	if(customer_account_exists($payee_account) != 1)
	{
		$error[] = 'Account Number not exists!';
	}

	if($payee_name == '')
	{
		$error[] = 'Enter Payee Account Name';
	}

	if($payee_account == '')
	{
		$error[] = 'Enter Payee Account Number';
	}

	if($amount == '')
	{
		$error[] = 'Enter Amout to send funds!';
	}

	if($details['customer_deposit'] == 0)
	{
		$error[] = 'Insufficient Balance!';
	}

	if($details['customer_deposit'] <= $amount)
	{
		$error[] = 'Available Balance is Low!';
	}

	if(empty($error))
	{

		$debit = $details['customer_deposit'] - $amount;

		mysql_query("UPDATE customer SET customer_deposit = '$debit' WHERE customer_name = '$_SESSION[customer_name]'");

		$payee = user_assets_account($payee_account);

		$new_deposit = $payee['customer_deposit'] + $amount;

		mysql_query("UPDATE customer SET customer_deposit = '$new_deposit' WHERE customer_name = '$payee[customer_name]'");


		$date = date('d/M/Y');
		$statement = mysql_query("INSERT INTO statement (customer_account, payee_account, amount, dated) VALUES('$details[customer_account]', '$payee[customer_account]', '$amount', '$date')");

		if($statement)
		{
			echo '<script>alert("Fund Transfered Successfully!");</script>';
			//header('location: transfer.php');
		}


	}
	else
	{
		foreach ($error as $key => $value) {
			?>
				<script type="text/javascript">
				$(document).ready(function(){
					alert(<?php echo '"'.$value.'"'; ?>);
				});
				</script>
			<?php
		}
	}

}

?>

<?php include 'temp/navigation.php'; ?>

<div id="header-with-tabs">

	<div class="page-full-width clearfix">
	
		

	<a href="#" class="fr" id="company-logo-small"><!--<img src="img/company-logo.png" alt="Techforge" >--></a>


	</div><!-- page-full-width -->

</div><!-- header -->

<div id="content">
	
	<div class="page-full-width clearfix">
	<h1>Change Password</h1><br>

		<form action="" method="post">

			<fieldset>

				<p>
				<label>Current Password *</label>
				<input type="password" class="default-width-input round" name="current_password"  />
				</p>

				<p>
				<label>New Password *</label>
				<input type="password" class="default-width-input round" name="new_password"  />
				</p>

				

				<input type="submit" value="CHANGE PASSWORD" name="edit" class="button image-right text-upper round blue ic-right-arrow" id="add-category">

			</fieldset>

		</form>
		

	</div><!-- page-full-width -->

</div><!-- content -->

<div id="footer">
	
	<p>&copy; Copyright 2015. All rights reserved</p>

</div><!-- footer -->
<script type="text/javascript">

</script>
</body>
</html>