-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2015 at 01:27 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE IF NOT EXISTS `bank` (
`bank_id` int(11) NOT NULL,
  `username` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `username`, `password`) VALUES
(1, 'boopathi', '972ae52621668f045e61bd75160131e8');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
`customer_id` int(11) NOT NULL,
  `customer_account` varchar(300) NOT NULL,
  `customer_name` varchar(300) NOT NULL,
  `customer_password` varchar(300) NOT NULL,
  `customer_deposit` varchar(300) NOT NULL,
  `date` varchar(300) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_account`, `customer_name`, `customer_password`, `customer_deposit`, `date`) VALUES
(1, '2267834', 'boopathi', 'indian', '1500', ''),
(2, '924520', 'hari', 'indian', '4800', ''),
(3, '8560', 'ruban', 'indian', '6400', ''),
(4, '569354', 'demo', 'indian', '5500', ''),
(5, '998098', 'someone', 'indian', '6500', '');

-- --------------------------------------------------------

--
-- Table structure for table `hacker`
--

CREATE TABLE IF NOT EXISTS `hacker` (
`hacker_id` int(11) NOT NULL,
  `username` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hacker`
--

INSERT INTO `hacker` (`hacker_id`, `username`, `password`) VALUES
(1, 'boopathi', '972ae52621668f045e61bd75160131e8');

-- --------------------------------------------------------

--
-- Table structure for table `statement`
--

CREATE TABLE IF NOT EXISTS `statement` (
`statement_id` int(11) NOT NULL,
  `customer_account` varchar(300) NOT NULL,
  `payee_account` varchar(300) NOT NULL,
  `amount` varchar(300) NOT NULL,
  `type` int(11) NOT NULL,
  `dated` varchar(300) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `statement`
--

INSERT INTO `statement` (`statement_id`, `customer_account`, `payee_account`, `amount`, `type`, `dated`) VALUES
(7, '2267834', '8560', '200', 0, '08/Feb/2015'),
(8, '2267834', '8560', '200', 0, '08/Feb/2015'),
(9, '2267834', '924520', '100', 0, '10/Feb/2015'),
(10, '2267834', '569354', '500', 0, '10/Feb/2015'),
(11, '2267834', '998098', '1000', 0, '11/Feb/2015'),
(12, '998098', '2267834', '1000', 0, '11/Feb/2015'),
(13, '2267834', '998098', '1500', 0, '11/Feb/2015');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
 ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
 ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `hacker`
--
ALTER TABLE `hacker`
 ADD PRIMARY KEY (`hacker_id`);

--
-- Indexes for table `statement`
--
ALTER TABLE `statement`
 ADD PRIMARY KEY (`statement_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `hacker`
--
ALTER TABLE `hacker`
MODIFY `hacker_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `statement`
--
ALTER TABLE `statement`
MODIFY `statement_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
