<?php include 'core/connection.php'; ?>
<?php include 'core/function.php'; ?>
<?php
ob_start();
session_start();

if(!isset($_SESSION['customer_name']))
{
	header('location: login.php');
}


$details = user_assets($_SESSION['customer_name']);

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />
</head>
<body>


<?php include 'temp/navigation.php'; ?>

<div id="header-with-tabs">

	<div class="page-full-width clearfix">
	
		<ul id="tabs">
			<li><a href="home.php" class="active-tab">ACCOUNT SUMMARY</a></li>
			<li><a href="transfer.php">TRANSFER FUNDS</a></li>
			
		</ul>

	<a href="#" class="fr" id="company-logo-small"><!--<img src="img/company-logo.png" alt="Techforge" >--></a>


	</div><!-- page-full-width -->

</div><!-- header -->

<div id="content">
	
	<div class="page-full-width clearfix">

		
		<table class="account">
			<thead>
				<tr>
					<th>Total Balance</th>
				</tr>
			</thead>
	
		<tbody>
			<tr>
				<td>
					<h1>Savings INR <?php echo $details['customer_deposit']; ?></h1>
				</td>

			</tr>
			<tr>
				<td>Account <span><?php echo $details['customer_deposit']; ?> INR</span></td>
			</tr>
			<tr>
				<td>Demat <span>0 INR</span></td>
			</tr>
			<tr>
				<td>Deposite <span>0 INR</span></td>
			</tr>
		</tbody>
		</table>

		<a href="statement.php" class="sum-but clearfix">LINK TO SUMMARY</a>

	</div><!-- page-full-width -->

</div><!-- content -->
</body>
</html>