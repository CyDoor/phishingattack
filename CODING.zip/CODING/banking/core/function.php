<?php

function user_assets($customer_name)
{
	$details = Array();
	$sql = mysql_query("SELECT * FROM customer WHERE customer_name = '$customer_name'");
	while($fetch = mysql_fetch_assoc($sql))
	{
		$details['customer_id'] = $fetch['customer_id'];
		$details['customer_account'] = $fetch['customer_account'];
		$details['customer_name'] = $fetch['customer_name'];
		$details['customer_password'] = $fetch['customer_password'];
		$details['customer_deposit'] = $fetch['customer_deposit'];
		$details['date'] = $fetch['date'];
	}
	return $details;

}

function user_assets_account($customer_account)
{
	$details = Array();
	$sql = mysql_query("SELECT * FROM customer WHERE customer_account = '$customer_account'");
	while($fetch = mysql_fetch_assoc($sql))
	{
		$details['customer_id'] = $fetch['customer_id'];
		$details['customer_account'] = $fetch['customer_account'];
		$details['customer_name'] = $fetch['customer_name'];
		$details['customer_deposit'] = $fetch['customer_deposit'];
		$details['date'] = $fetch['date'];
	}
	return $details;

}

function customer_account_exists($customer_account)
{

	$sql = mysql_query("SELECT * FROM customer WHERE customer_account = '$customer_account'");
	
	return mysql_num_rows($sql);
}

function customer_name_exists($customer_name)
{

	$sql = mysql_query("SELECT * FROM customer WHERE customer_name = '$customer_name'");
	
	return mysql_num_rows($sql);
}


?>